#Added additional libaries
import cv2
import numpy as np
import tensorflow as tf
from keras.models import model_from_yaml
import rospy

from styx_msgs.msg import TrafficLight


class TLClassifier(object):
    def __init__(self):
        #TODO load classifier
        rospy.loginfo('Loading Classifier')

        # Create model
        classifier_yaml_file = open('light_classification/traffic_light_classifier.yaml', 'r')
        loaded_classifier_model_yaml = classifier_yaml_file.read()
        classifier_yaml_file.close()
        self.classifier_model = model_from_yaml(loaded_classifier_model_yaml)

        # Load weights 
        self.classifier_model.load_weights('light_classification/traffic_light_classifier_weights.h5')
        self.graph = tf.get_default_graph()

        rospy.loginfo('Classifier loaded')


    def get_classification(self, image):
        """Determines the color of the traffic light in the image
        Args:
            image (cv::Mat): image containing the traffic light
        Returns:
            int: ID of traffic light color (specified in styx_msgs/TrafficLight)
        """
        #TODO implement light color prediction
        light_state_pred = -1 #default state = unknown

        with self.graph.as_default():
            light_state_pred = np.argmax(self.classifier_model.predict(cv2.resize(image, (224,224)).reshape(1,224,224,3))[0])

        if light_state_pred == 0:
            return TrafficLight.GREEN
        elif light_state_pred == 1:
            return TrafficLight.YELLOW
        elif light_state_pred == 2:
            return TrafficLight.RED
        else:
            return TrafficLight.UNKNOWN